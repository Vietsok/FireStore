package com.lokavida.firestoreexample;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    /**
     * Les Clées pour appeler les champs de la BDD
     **/
    private static final String TAG = "MAIN";
    private static final String KEY_TITRE = "titre";
    private static final String KEY_NOTE = "note";

    private EditText etTitre, etNote;
    private TextView tvShowNote, tvSavedNote;


    /**
     * Initialisation des widgets
     **/
    private void init() {

        etTitre = findViewById(R.id.etTitle);
        etNote = findViewById(R.id.etNote);
        tvShowNote = findViewById(R.id.tvShowNote);
        tvSavedNote = findViewById(R.id.tvSavedNote);


    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    public void saveNote(View v){
        Toast.makeText(MainActivity.this, "Bouton sade pressed", Toast.LENGTH_LONG).show();
    }



    public void showNote(View v){
        Toast.makeText(MainActivity.this, "Bouton Afficher pressed", Toast.LENGTH_LONG).show();
    }


}