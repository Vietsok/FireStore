package com.lokavida.firestoreexample;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {


    /**
     * Les Clées pour appeler les champs de la BDD
     **/
    private static final String TAG = "MAIN";
    private static final String KEY_TITRE = "titre";
    private static final String KEY_NOTE = "note";

    private EditText etTitre, etNote;
    private TextView tvShowNote, tvSavedNote;


    /*** BDD ***/
    // créer une BDD
    private FirebaseFirestore db;
    // ID du document -- Action sur les champs
    private DocumentReference noteRef;


    /** END - BDD **/

    /**
     * Initialisation des widgets
     **/
    private void init() {

        etTitre = findViewById(R.id.etTitle);
        etNote = findViewById(R.id.etNote);
        tvShowNote = findViewById(R.id.tvShowNote);
        tvSavedNote = findViewById(R.id.tvSavedNote);


        /*** BDD ***/
        /** Connexion a lo BDD **/
        db = FirebaseFirestore.getInstance();
        /**
         // noteRef = db.collection("notes").document("Ma première note"); **/
        noteRef = db.document("notes/Ma première note");


        /** END - BDD **/

    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();
    }


    public void saveNote(View v) {
        /** Toast.makeText(MainActivity.this, "Bouton sade pressed", Toast.LENGTH_LONG).show();**/
        String titre = etTitre.getText().toString().trim();
        String note = etNote.getText().toString().trim();

        /** Envoyer les valeurs **/
        Map<String, Object> contenuNote = new HashMap<>();
        contenuNote.put(KEY_TITRE, titre);
        contenuNote.put(KEY_NOTE, note);

        noteRef.set(contenuNote)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Toast.makeText(MainActivity.this, "Note enregistrée", Toast.LENGTH_SHORT).show();

                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(MainActivity.this, "Erreur Enregistrement", Toast.LENGTH_SHORT).show();

                    }
                });


    }

    @Override
    protected void onStart() {
        super.onStart();
        noteRef.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {

            @Override
            public void onEvent(@Nullable DocumentSnapshot value, @Nullable FirebaseFirestoreException error) {

                if (error != null) {
                    Toast.makeText(MainActivity.this, "Erreur lors du chargement", Toast.LENGTH_SHORT).show();

                    Log.e(TAG, error.toString());
                    return; /** pour pas que l'application plante **/
                }

                if(value.exists()){
                    String titre = value.getString(KEY_TITRE);
                    String note = value.getString(KEY_NOTE);

                    /* Methode 2 */
                    tvSavedNote.setText("Titre" + titre + "\n" + "Note :" + note);
                }else{
                    tvSavedNote.setText("");
                }


            }
        });
    }

    public void showNote(View v) {

        /**  Toast.makeText(MainActivity.this, "Bouton Afficher pressed", Toast.LENGTH_LONG).show(); **/
        noteRef.get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {

                        if (documentSnapshot.exists()) {
                            String titre = documentSnapshot.getString(KEY_TITRE);
                            String note = documentSnapshot.getString(KEY_NOTE);
                            /** ou
                             /** Map<String, Object> note = documentSnapshot.getData(); **/

                            tvShowNote.setText("Titre" + titre + "\n" + "Note :" + note);

                        } else {
                            Toast.makeText(MainActivity.this, "Pas de document", Toast.LENGTH_SHORT).show();
                            Log.e(TAG, etNote.toString());
                        }


                    }
                })

                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                    }
                });
    }

    public void clickButton() {
        // Definition et valorisation du bouton
        Button button = findViewById(R.id.btnSave);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "", Toast.LENGTH_SHORT).show();
            }
        });
    }


    /**
     public void multiChoice(View view) {
     Button button = (Button) view;

     switch (button.getId()) {

     case R.id.btnSave:
     // Action
     break;

     case R.id.btnShow:
     // Action
     break;

     default:
     // Action
     break;

     }
     }**/


}