package com.lokavida.firestoreexample;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.lokavida.firestoreexample.Model.ModelNote;

import java.util.HashMap;
import java.util.Map;

public class MainActivity3 extends AppCompatActivity {


    /**
     * Les Clées pour appeler les champs de la BDD
     **/
    private static final String TAG = "MAIN";
    private static final String KEY_TITRE = "titre";
    private static final String KEY_NOTE = "note";

    private EditText etTitre, etNote;
    private TextView tvShowNote, tvSavedNote;


    /*** BDD ***/
    // créer une BDD
    private FirebaseFirestore db;
    // ID du document -- Action sur les champs
    private DocumentReference noteRef;

    /*** adding v3 **/
    private CollectionReference noteCollectionRef;


    /** END - BDD **/

    /**
     * Initialisation des widgets
     **/
    private void init() {

        etTitre = findViewById(R.id.etTitle);
        etNote = findViewById(R.id.etNote);
        tvShowNote = findViewById(R.id.tvShowNote);
        tvSavedNote = findViewById(R.id.tvSavedNote);


        /*** BDD ***/
        /** Connexion a lo BDD **/
        db = FirebaseFirestore.getInstance();
        /**
         // noteRef = db.collection("notes").document("Ma première note"); **/
        noteRef = db.document("notes/Ma première note");


        /*** v3 Pour ajouter des documents dans la collection avec des id differents a chaque fois **/
        noteCollectionRef = db.collection("notes");


        /** END - BDD **/

    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        init();
    }


    public void AddNote(View view) {
        String titre = etTitre.getText().toString().trim();
        String note = etNote.getText().toString().trim();
        ModelNote contenuNote = new ModelNote(titre, note);
        noteCollectionRef.add(contenuNote)
                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {

                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                    }
                });


    }


    public void saveNote(View v) {
        /** Toast.makeText(MainActivity.this, "Bouton sade pressed", Toast.LENGTH_LONG).show();**/
        String titre = etTitre.getText().toString().trim();
        String note = etNote.getText().toString().trim();

        /**** Add *****/
        ModelNote contenuNote = new ModelNote(titre, note);

        noteCollectionRef.add(contenuNote); // Dans une collection on ne peux pas utiliser un .set mais un .add


        /**** Add *****/


        noteRef.set(contenuNote)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Toast.makeText(MainActivity3.this, "Note enregistrée", Toast.LENGTH_SHORT).show();

                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(MainActivity3.this, "Erreur Enregistrement", Toast.LENGTH_SHORT).show();

                    }
                });


    }


    public void showNote(View v) {

        /**  Toast.makeText(MainActivity.this, "Bouton Afficher pressed", Toast.LENGTH_LONG).show(); **/
        noteCollectionRef.get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot listeSnapshots) {
                        String notes = "";

                        /** each : Recherche de chaque items dans la liste **/

                        for (QueryDocumentSnapshot documentSnapshots : listeSnapshots) {
                            // Pour chaque docuement(Snapshot) de la liste
                            ModelNote contenuNote = documentSnapshots.toObject(ModelNote.class);

                            contenuNote.setDocumentId(documentSnapshots.getId());

                            String documentId = contenuNote.getDocumentId();
                            String titre = contenuNote.getTitre();
                            String note = contenuNote.getNote();

                            notes += documentId +"\nTitre: "+ titre +"\nNote: "+ note+"\n\n\n";


                        }
                        tvSavedNote.setText(notes);
                        }
                    });


                }


        @Override
        protected void onStart () {
            super.onStart();

        }

    }