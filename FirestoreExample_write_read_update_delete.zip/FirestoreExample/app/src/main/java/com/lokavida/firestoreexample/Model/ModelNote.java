package com.lokavida.firestoreexample.Model;

/** On créer notre model avec un constructeur vide, un constructeur avec parametre(s), un getter / setter depuis le generator **/
public class ModelNote {

    private String titre;
    private String note;

    /** Start - Constructeur vide - Permet de ne pas faire planter l'application **/
    public ModelNote() {
    }

    /** End - Constructeur vide **/

    /** Begin - Constructeur **/
    public ModelNote(String titre, String note) {
        this.titre = titre;
        this.note = note;
    }
    /** End - Constructeur **/


    /*** Begin - Getter Setter **/

    public String getTitre() {
        return titre;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    /*** End - Getter Setter **/
}
